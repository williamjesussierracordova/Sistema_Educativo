/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package vista_profesor;

import com.william.proyectoadd.conexion;
import com.william.proyectoadd.interfazPrincipal.Login;
import controladores.controlador_estudiantes;
import controladores.controlador_horarios;
import controladores.controlador_materias;
import controladores.controlador_matriculas;
import controladores.controlador_profesores;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelos.modelo_estudiantes;
import modelos.modelo_horarios;
import modelos.modelo_profesores;
import vista_director.vista_horario;

/**
 *
 * @author WILLIAM
 */
public class BuscarHorario extends javax.swing.JInternalFrame {
conexion connection= new conexion();
Connection conexion1=connection.establecerConexion();

DefaultTableModel model = new DefaultTableModel();

    controlador_profesores ce= new controlador_profesores();
controlador_matriculas cmatriculas= new controlador_matriculas();
controlador_horarios ch= new controlador_horarios();
controlador_materias cmm=new controlador_materias();
void updateHorario(){
    try {
            // TODO add your handling code here:
            Connection connection1 = connection.establecerConexion();

            for (int i = model.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }

            modelo_profesores estudiante1=ce.buscarRegistro(connection1, Login.profesorid);

            if(estudiante1!=null){
                ArrayList<modelo_horarios> datosHorarios = new ArrayList();
                for(int i=0;i<ch.buscarHorarioProfesor(connection1,Login.profesorid).size();i++){
                    if(!ch.buscarHorarioProfesor(connection1,Login.profesorid).isEmpty()){
                        datosHorarios=ch.buscarHorarioProfesor(connection1,Login.profesorid);
                    }
                }

                String[] linea1= new String[6];
                String[] linea2= new String[6];
                String[] linea3= new String[6];
                String[] linea4= new String[6];
                String[] linea5= new String[6];

                linea1[0] = "07:00 - 08:45";
                linea2[0] = "09:00 - 10:45";
                linea3[0] = "11:00 - 12:45";
                linea4[0] = "14:00 - 15:45";
                linea5[0] = "16:00 - 17:45";
                if(!datosHorarios.isEmpty()){
                    for(int i=0;i<datosHorarios.size();i++){
                        if("07:00".equals(datosHorarios.get(i).getHoraInicio())){
                            if(null != datosHorarios.get(i).getDia())switch (datosHorarios.get(i).getDia()) {
                                case "Lunes":
                                linea1[1]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Martes":
                                linea1[2] = cmm.buscarMaterias(connection1 , datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Miercoles":
                                linea1[3]=cmm.buscarMaterias(connection1 , datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Jueves":
                                linea1[4]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Viernes":
                                linea1[5]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                default:
                                break;
                            }
                        }
                        else if("09:00".equals(datosHorarios.get(i).getHoraInicio())){
                            if(null != datosHorarios.get(i).getDia())switch (datosHorarios.get(i).getDia()) {
                                case "Lunes":
                                linea2[1]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Martes":
                                linea2[2]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Miercoles":
                                linea2[3]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Jueves":
                                linea2[4]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Viernes":
                                linea2[5]=cmm.buscarMaterias(connection1 , datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                default:
                                break;
                            }
                        }
                        else if("11:00".equals(datosHorarios.get(i).getHoraInicio())){
                            if(null != datosHorarios.get(i).getDia())switch (datosHorarios.get(i).getDia()) {
                                case "Lunes":
                                linea3[1]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Martes":
                                linea3[2]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Miercoles":
                                linea3[3]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Jueves":
                                linea3[4]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Viernes":
                                linea3[5]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                default:
                                break;
                            }
                        }
                        else if("14:00".equals(datosHorarios.get(i).getHoraInicio())){
                            if(null != datosHorarios.get(i).getDia())switch (datosHorarios.get(i).getDia()) {
                                case "Lunes":
                                linea4[1]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Martes":
                                linea4[2]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Miercoles":
                                linea4[3]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Jueves":
                                linea4[4]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Viernes":
                                linea4[5]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                default:
                                break;
                            }
                        }
                        else if("16:00".equals(datosHorarios.get(i).getHoraInicio())){
                            if(null != datosHorarios.get(i).getDia())switch (datosHorarios.get(i).getDia()) {
                                case "Lunes":
                                linea5[1]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Martes":
                                linea5[2]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Miercoles":
                                linea5[3]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Jueves":
                                linea5[4]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                case "Viernes":
                                linea5[5]=cmm.buscarMaterias(connection1, datosHorarios.get(i).getMateriaID())+"/ ID:"+String.valueOf(datosHorarios.get(i).getHorarioID());
                                break;
                                default:
                                break;
                            }
                        }

                    }

                    model.addRow(linea1);
                    model.addRow(linea2);
                    model.addRow(linea3);
                    model.addRow(linea4);
                    model.addRow(linea5);

                    /*do{
                        ArrayList<modelo_horarios> listahorarios= ch.buscarHorario(connection.establecerConexion(), me.getHorario1());
                    }while();
                    */
                }
                else{
                    JOptionPane.showMessageDialog(rootPane, "El profesor no tiene horarios registrados para este periodo educativo ", "Matricula no encontrada", JOptionPane.ERROR_MESSAGE);
                }

            }
            else{
                JOptionPane.showMessageDialog(rootPane, "El DNI ingresado es incorrecto y/o no se encuentra registrado ", "Estudiante no encontrado", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            Logger.getLogger(vista_horario.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    /**
     * Creates new form BuscarCursos
     */
    public BuscarHorario() {
        initComponents();
       model.addColumn("Horario");
        model.addColumn("Lunes");
        model.addColumn("Martes");
        model.addColumn("Miercoles");
        model.addColumn("Jueves");
        model.addColumn("Viernes");
        this.jTable1.setModel(model);
        jTable1.setDefaultEditor(Object.class, null);
        updateHorario();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 30)); // NOI18N
        jLabel1.setText("Horario");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 758, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(337, 337, 337))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
