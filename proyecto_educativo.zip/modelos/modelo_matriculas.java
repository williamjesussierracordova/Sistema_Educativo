/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author WILLIAM
 */
public class modelo_matriculas {
    String estudianteID;
    int gradoID;
    int horario1;
    int horario2;
    int horario3;
    int horario4;
    int horario5;
    int horario6;
    int horario7;
    int horario8;
    int horario9;
    int horario10;
    int horario11;
    int horario12;
    int horario13;
    int horario14;
    int horario15;
    int horario16;
    int horario17;
    int horario18;
    int horario19;
    int horario20;
    int horario21;
    int horario22;
    int horario23;
    int horario24;
    int horario25;

    public modelo_matriculas() {
    }

    public modelo_matriculas(String estudianteID, int gradoID, int horario1, int horario2, int horario3, int horario4, int horario5, int horario6, int horario7, int horario8, int horario9, int horario10, int horario11, int horario12, int horario13, int horario14, int horario15, int horario16, int horario17, int horario18, int horario19, int horario20, int horario21, int horario22, int horario23, int horario24, int horario25) {
        this.estudianteID = estudianteID;
        this.gradoID = gradoID;
        this.horario1 = horario1;
        this.horario2 = horario2;
        this.horario3 = horario3;
        this.horario4 = horario4;
        this.horario5 = horario5;
        this.horario6 = horario6;
        this.horario7 = horario7;
        this.horario8 = horario8;
        this.horario9 = horario9;
        this.horario10 = horario10;
        this.horario11 = horario11;
        this.horario12 = horario12;
        this.horario13 = horario13;
        this.horario14 = horario14;
        this.horario15 = horario15;
        this.horario16 = horario16;
        this.horario17 = horario17;
        this.horario18 = horario18;
        this.horario19 = horario19;
        this.horario20 = horario20;
        this.horario21 = horario21;
        this.horario22 = horario22;
        this.horario23 = horario23;
        this.horario24 = horario24;
        this.horario25 = horario25;
    }

    public String getEstudianteID() {
        return estudianteID;
    }

    public void setEstudianteID(String estudianteID) {
        this.estudianteID = estudianteID;
    }

    public int getGradoID() {
        return gradoID;
    }

    public void setGradoID(int gradoID) {
        this.gradoID = gradoID;
    }

    public int getHorario1() {
        return horario1;
    }

    public void setHorario1(int horario1) {
        this.horario1 = horario1;
    }

    public int getHorario2() {
        return horario2;
    }

    public void setHorario2(int horario2) {
        this.horario2 = horario2;
    }

    public int getHorario3() {
        return horario3;
    }

    public void setHorario3(int horario3) {
        this.horario3 = horario3;
    }

    public int getHorario4() {
        return horario4;
    }

    public void setHorario4(int horario4) {
        this.horario4 = horario4;
    }

    public int getHorario5() {
        return horario5;
    }

    public void setHorario5(int horario5) {
        this.horario5 = horario5;
    }

    public int getHorario6() {
        return horario6;
    }

    public void setHorario6(int horario6) {
        this.horario6 = horario6;
    }

    public int getHorario7() {
        return horario7;
    }

    public void setHorario7(int horario7) {
        this.horario7 = horario7;
    }

    public int getHorario8() {
        return horario8;
    }

    public void setHorario8(int horario8) {
        this.horario8 = horario8;
    }

    public int getHorario9() {
        return horario9;
    }

    public void setHorario9(int horario9) {
        this.horario9 = horario9;
    }

    public int getHorario10() {
        return horario10;
    }

    public void setHorario10(int horario10) {
        this.horario10 = horario10;
    }

    public int getHorario11() {
        return horario11;
    }

    public void setHorario11(int horario11) {
        this.horario11 = horario11;
    }

    public int getHorario12() {
        return horario12;
    }

    public void setHorario12(int horario12) {
        this.horario12 = horario12;
    }

    public int getHorario13() {
        return horario13;
    }

    public void setHorario13(int horario13) {
        this.horario13 = horario13;
    }

    public int getHorario14() {
        return horario14;
    }

    public void setHorario14(int horario14) {
        this.horario14 = horario14;
    }

    public int getHorario15() {
        return horario15;
    }

    public void setHorario15(int horario15) {
        this.horario15 = horario15;
    }

    public int getHorario16() {
        return horario16;
    }

    public void setHorario16(int horario16) {
        this.horario16 = horario16;
    }

    public int getHorario17() {
        return horario17;
    }

    public void setHorario17(int horario17) {
        this.horario17 = horario17;
    }

    public int getHorario18() {
        return horario18;
    }

    public void setHorario18(int horario18) {
        this.horario18 = horario18;
    }

    public int getHorario19() {
        return horario19;
    }

    public void setHorario19(int horario19) {
        this.horario19 = horario19;
    }

    public int getHorario20() {
        return horario20;
    }

    public void setHorario20(int horario20) {
        this.horario20 = horario20;
    }

    public int getHorario21() {
        return horario21;
    }

    public void setHorario21(int horario21) {
        this.horario21 = horario21;
    }

    public int getHorario22() {
        return horario22;
    }

    public void setHorario22(int horario22) {
        this.horario22 = horario22;
    }

    public int getHorario23() {
        return horario23;
    }

    public void setHorario23(int horario23) {
        this.horario23 = horario23;
    }

    public int getHorario24() {
        return horario24;
    }

    public void setHorario24(int horario24) {
        this.horario24 = horario24;
    }

    public int getHorario25() {
        return horario25;
    }

    public void setHorario25(int horario25) {
        this.horario25 = horario25;
    }
    
    
}
