/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author WILLIAM
 */
public class modelo_cursosGrado {
    int gradoID;
    int grado;
    int nivel;
    int curso1;
    int curso2;
    int curso3;
    int curso4;
    int curso5;
    int curso6;
    int curso7;
    int curso8;
    int curso9;
    int curso10;
    int curso11;
    int curso12;
    int curso13;
    int curso14;
    int curso15;

    public modelo_cursosGrado(int gradoID, int grado, int nivel, int curso1, int curso2, int curso3, int curso4, int curso5, int curso6, int curso7, int curso8, int curso9, int curso10, int curso11, int curso12, int curso13, int curso14, int curso15) {
        this.gradoID = gradoID;
        this.grado = grado;
        this.nivel = nivel;
        this.curso1 = curso1;
        this.curso2 = curso2;
        this.curso3 = curso3;
        this.curso4 = curso4;
        this.curso5 = curso5;
        this.curso6 = curso6;
        this.curso7 = curso7;
        this.curso8 = curso8;
        this.curso9 = curso9;
        this.curso10 = curso10;
        this.curso11 = curso11;
        this.curso12 = curso12;
        this.curso13 = curso13;
        this.curso14 = curso14;
        this.curso15 = curso15;
    }

    public modelo_cursosGrado() {
    }

    public int getGradoID() {
        return gradoID;
    }

    public void setGradoID(int gradoID) {
        this.gradoID = gradoID;
    }

    public int getGrado() {
        return grado;
    }

    public void setGrado(int grado) {
        this.grado = grado;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getCurso1() {
        return curso1;
    }

    public void setCurso1(int curso1) {
        this.curso1 = curso1;
    }

    public int getCurso2() {
        return curso2;
    }

    public void setCurso2(int curso2) {
        this.curso2 = curso2;
    }

    public int getCurso3() {
        return curso3;
    }

    public void setCurso3(int curso3) {
        this.curso3 = curso3;
    }

    public int getCurso4() {
        return curso4;
    }

    public void setCurso4(int curso4) {
        this.curso4 = curso4;
    }

    public int getCurso5() {
        return curso5;
    }

    public void setCurso5(int curso5) {
        this.curso5 = curso5;
    }

    public int getCurso6() {
        return curso6;
    }

    public void setCurso6(int curso6) {
        this.curso6 = curso6;
    }

    public int getCurso7() {
        return curso7;
    }

    public void setCurso7(int curso7) {
        this.curso7 = curso7;
    }

    public int getCurso8() {
        return curso8;
    }

    public void setCurso8(int curso8) {
        this.curso8 = curso8;
    }

    public int getCurso9() {
        return curso9;
    }

    public void setCurso9(int curso9) {
        this.curso9 = curso9;
    }

    public int getCurso10() {
        return curso10;
    }

    public void setCurso10(int curso10) {
        this.curso10 = curso10;
    }

    public int getCurso11() {
        return curso11;
    }

    public void setCurso11(int curso11) {
        this.curso11 = curso11;
    }

    public int getCurso12() {
        return curso12;
    }

    public void setCurso12(int curso12) {
        this.curso12 = curso12;
    }

    public int getCurso13() {
        return curso13;
    }

    public void setCurso13(int curso13) {
        this.curso13 = curso13;
    }

    public int getCurso14() {
        return curso14;
    }

    public void setCurso14(int curso14) {
        this.curso14 = curso14;
    }

    public int getCurso15() {
        return curso15;
    }

    public void setCurso15(int curso15) {
        this.curso15 = curso15;
    }
    
    
    
}
