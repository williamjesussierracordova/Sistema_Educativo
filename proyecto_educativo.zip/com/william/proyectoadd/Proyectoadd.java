/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.william.proyectoadd;
import com.william.proyectoadd.interfazPrincipal.Login;
import java.sql.*;
/**
 *
 * @author WILLIAM
 */
public class Proyectoadd {

    public static void main(String[] args) throws SQLException {
        Login vl= new Login();
        vl.setVisible(true);
    }
}
